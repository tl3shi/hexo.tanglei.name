package PACCluster;

###################################################################
# This file is part of PAC( Perl Auto Connector)
#
# Copyright (C) 2010  David Torrejon Vaquerizas
# 
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
###################################################################

$|++;

###################################################################
# Import Modules

use FindBin qw ( $RealBin $Bin $Script );
use lib $RealBin . '/lib', $RealBin . '/lib/ex';

# Standard
use strict;
use warnings;

# GTK2
use Gtk2 '-init';
use Gtk2::Ex::Simple::List;

# PAC modules
use PACUtils;
use PACPCC;

# END: Import Modules
###################################################################

###################################################################
# Define GLOBAL CLASS variables

my $APPNAME			= $PACUtils::APPNAME;
my $APPVERSION		= $PACUtils::APPVERSION;

my $ICON_ON			= Gtk2::Gdk::Pixbuf -> new_from_file_at_scale( $RealBin . '/res/pac_terminal16x16.png', 16, 16, 0 );
my $ICON_OFF		= Gtk2::Gdk::Pixbuf -> new_from_file_at_scale( $RealBin . '/res/pac_terminal_x16x16.png', 16, 16, 0 );
# END: Define GLOBAL CLASS variables
###################################################################

###################################################################
# START: Define PUBLIC CLASS methods

sub new
{
	my $class	= shift;
	my $self	= {};
	
	$self	-> {_RUNNING}		= shift;
	
	$self	-> {_CLUSTERS}		= undef;
	$self	-> {_WINDOWCLUSTER}	= undef;
	
	# Build the GUI
	_initGUI( $self ) or return 0;

	# Setup callbacks
	_setupCallbacks( $self );
	
	bless( $self, $class );
	return $self;
}

# DESTRUCTOR
sub DESTROY
{
	my $self = shift;
	undef $self;
	return 1;
}

# Start GUI and launch connection
sub show
{
	my $self = shift;
	
	$self -> _updateGUI;
	
	$$self{_WINDOWCLUSTER}{main} -> set_title( "Cluster Administration : $APPNAME (v$APPVERSION)" );
	$$self{_WINDOWCLUSTER}{main} -> set_position( 'center' );
	$$self{_WINDOWCLUSTER}{main} -> show_all;
	$$self{_WINDOWCLUSTER}{main} -> present;
	
	$$self{_WINDOWCLUSTER}{treeTerminals} -> grab_focus();
	$$self{_WINDOWCLUSTER}{treeTerminals} -> select( 0 );
	
	return 1;
}

# END: Define PUBLIC CLASS methods
###################################################################

###################################################################
# START: Define PRIVATE CLASS functions

sub _initGUI
{
	my $self = shift;
	
	$$self{_WINDOWCLUSTER}{main} = Gtk2::Window -> new;
	$$self{_WINDOWCLUSTER}{main} -> set_position( 'center' );
	$$self{_WINDOWCLUSTER}{main} -> set_icon_name( 'pac-app-big' );
	$$self{_WINDOWCLUSTER}{main} -> set_size_request( -1, -1 );
	$$self{_WINDOWCLUSTER}{main} -> set_default_size( 600, 400 );
	$$self{_WINDOWCLUSTER}{main} -> set_resizable( 1 );
		
		my $vbox1 = Gtk2::VBox -> new( 0, 0 );
		$$self{_WINDOWCLUSTER}{main} -> add( $vbox1 );
			
			my $hbox1 = Gtk2::HBox -> new( 0, 0 );
			$vbox1 -> pack_start( $hbox1, 1, 1, 0 );
				
				my $frame0 = Gtk2::Frame -> new( ' UNCLUSTERED TERMINALS: ' );
				$hbox1 -> pack_start( $frame0, 1, 1, 0 );
				my $frame0lbl = Gtk2::Label -> new;
				$frame0lbl -> set_markup( ' <b>UNCLUSTERED TERMINALS:</b> ' );
				$frame0 -> set_label_widget( $frame0lbl );
					
					# Terminals list
					my $scroll1 = Gtk2::ScrolledWindow -> new();
					$frame0 -> add( $scroll1 );
					$scroll1 -> set_policy( 'automatic', 'automatic' );
					$hbox1 -> set_border_width( 5 );
						
						$$self{_WINDOWCLUSTER}{treeTerminals} = Gtk2::Ex::Simple::List -> new_from_treeview (
							Gtk2::TreeView -> new,
							'Opened Terminal(s):'	=> 'text',
							'UUID:'					=> 'hidden',
							'Status'				=> 'pixbuf'
						);
							
							$scroll1 -> add( $$self{_WINDOWCLUSTER}{treeTerminals} );
							$$self{_WINDOWCLUSTER}{treeTerminals} -> set_tooltip_text( 'List of available-unclustered connections' );
							$$self{_WINDOWCLUSTER}{treeTerminals} -> set_headers_visible( 0 );
							$$self{_WINDOWCLUSTER}{treeTerminals} -> get_selection -> set_mode( 'GTK_SELECTION_MULTIPLE' );
							my @col_terminals = $$self{_WINDOWCLUSTER}{treeTerminals} -> get_columns;
							$col_terminals[0] -> set_expand( 1 );
							$col_terminals[1] -> set_expand( 0 );
				
				# Buttons to Add/Del to/from Clusters
				my $vbox2 = Gtk2::VBox -> new( 0, 0 );
				$hbox1 -> pack_start( $vbox2, 0, 1, 0 );
					
					$$self{_WINDOWCLUSTER}{btnadd} = Gtk2::Button -> new_with_label( "Add to\nCluster" );
					$vbox2 -> pack_start( $$self{_WINDOWCLUSTER}{btnadd}, 1, 1, 0 );
					$$self{_WINDOWCLUSTER}{btnadd} -> set_image( Gtk2::Image -> new_from_stock( 'gtk-go-forward', 'GTK_ICON_SIZE_BUTTON' ) );
					$$self{_WINDOWCLUSTER}{btnadd} -> set_image_position( 'GTK_POS_BOTTOM' );
					$$self{_WINDOWCLUSTER}{btnadd} -> set_relief( 'GTK_RELIEF_NONE' );
					$$self{_WINDOWCLUSTER}{btnadd} -> set_sensitive( 0 );
					
					$$self{_WINDOWCLUSTER}{btndel} = Gtk2::Button -> new_with_label( "Del from\nCluster" );
					$vbox2 -> pack_start( $$self{_WINDOWCLUSTER}{btndel}, 1, 1, 0 );
					$$self{_WINDOWCLUSTER}{btndel} -> set_image( Gtk2::Image -> new_from_stock( 'gtk-go-back', 'GTK_ICON_SIZE_BUTTON' ) );
					$$self{_WINDOWCLUSTER}{btndel} -> set_image_position( 'GTK_POS_TOP' );
					$$self{_WINDOWCLUSTER}{btndel} -> set_relief( 'GTK_RELIEF_NONE' );
					$$self{_WINDOWCLUSTER}{btndel} -> set_sensitive( 0 );
				
				# Clusters list
				my $vbox3 = Gtk2::VBox -> new( 0, 0 );
				$hbox1 -> pack_start( $vbox3, 1, 1, 5 );
					
					my $frame1 = Gtk2::Frame -> new( ' CLUSTERS: ' );
					$vbox3 -> pack_start( $frame1, 0, 1, 0 );
					my $frame1lbl = Gtk2::Label -> new();
					$frame1lbl -> set_markup( ' <b>CLUSTERS:</b> ' );
					$frame1 -> set_label_widget( $frame1lbl );
						
						my $vbox4 = Gtk2::VBox -> new( 0, 0 );
						$frame1 -> add( $vbox4 );
						$vbox4 -> set_border_width( 5 );
							
							$$self{_WINDOWCLUSTER}{comboClusters} = Gtk2::ComboBox -> new_text();
							$vbox4 -> pack_start( $$self{_WINDOWCLUSTER}{comboClusters}, 0, 1, 0 );
							
							my $sep1 = Gtk2::HSeparator -> new();
							$vbox4 -> pack_start( $sep1, 0, 1, 5 );
							
							my $hbuttonbox1 = Gtk2::HButtonBox -> new();
							$vbox4 -> pack_start( $hbuttonbox1, 0, 1, 0 );
							$hbuttonbox1 -> set_layout( 'GTK_BUTTONBOX_EDGE' );
							$hbuttonbox1 -> set_homogeneous( 1 );
								
								$$self{_WINDOWCLUSTER}{addCluster} = Gtk2::Button -> new_from_stock( 'gtk-add' );
								$hbuttonbox1 -> add( $$self{_WINDOWCLUSTER}{addCluster} );
								$$self{_WINDOWCLUSTER}{addCluster} -> set( 'can-focus' => 0 );
								
								$$self{_WINDOWCLUSTER}{delCluster} = Gtk2::Button -> new_from_stock( 'gtk-delete' );
								$hbuttonbox1 -> add( $$self{_WINDOWCLUSTER}{delCluster} );
								$$self{_WINDOWCLUSTER}{delCluster} -> set( 'can-focus' => 0 );
								$$self{_WINDOWCLUSTER}{delCluster} -> set_sensitive( 0 );
								
					my $frame2 = Gtk2::Frame -> new( ' TERMINALS: ' );
					$vbox3 -> pack_start( $frame2, 1, 1, 0 );
					my $frame2lbl = Gtk2::Label -> new();
					$frame2lbl -> set_markup( ' <b>TERMINALS IN SELECTED CLUSTER:</b> ' );
					$frame2 -> set_label_widget( $frame2lbl );
						
						my $vbox5 = Gtk2::VBox -> new( 0, 0 );
						$frame2 -> add( $vbox5 );
							
							my $scroll2 = Gtk2::ScrolledWindow -> new();
							$vbox5 -> pack_start( $scroll2, 1, 1, 0 );
							$scroll2 -> set_policy( 'automatic', 'automatic' );
							$vbox5 -> set_border_width( 5 );
								
								$$self{_WINDOWCLUSTER}{treeClustered} = Gtk2::Ex::Simple::List -> new_from_treeview (
									Gtk2::TreeView -> new,
									'Terminal(s) in cluster:'	=> 'text',
									'UUID:'						=> 'hidden',
									'Status'					=> 'pixbuf'
								);
								$scroll2 -> add( $$self{_WINDOWCLUSTER}{treeClustered} );
								$$self{_WINDOWCLUSTER}{treeClustered} -> set_headers_visible( 0 );
								$$self{_WINDOWCLUSTER}{treeClustered} -> set_tooltip_text( 'List of connections included in the selected cluster above' );
								$$self{_WINDOWCLUSTER}{treeClustered} -> get_selection -> set_mode( 'GTK_SELECTION_MULTIPLE' );
								$$self{_WINDOWCLUSTER}{treeClustered} -> get_selection -> set_mode( 'GTK_SELECTION_MULTIPLE' );
								my @col_cluster = $$self{_WINDOWCLUSTER}{treeClustered} -> get_columns;
								$col_cluster[0] -> set_expand( 1 );
								$col_cluster[1] -> set_expand( 0 );
			
			$$self{_WINDOWCLUSTER}{buttonPCC} = Gtk2::Button -> new_with_mnemonic( '_Power Cluster Controller' );
			$$self{_WINDOWCLUSTER}{buttonPCC} -> set_image( Gtk2::Image -> new_from_stock( 'gtk-justify-fill', 'button' ) );
			$vbox1 -> pack_start( $$self{_WINDOWCLUSTER}{buttonPCC}, 0, 1, 5 );
			
			$vbox1 -> pack_start( Gtk2::HSeparator -> new, 0, 1, 0 );
			
			my $hbbox1 = Gtk2::HButtonBox -> new;
			$vbox1 -> pack_start( $hbbox1, 0, 1, 5 );
				
				$$self{_WINDOWCLUSTER}{btnOK} = Gtk2::Button -> new_from_stock( 'gtk-ok' );
				$hbbox1 -> set_layout( 'GTK_BUTTONBOX_END' );
				$hbbox1 -> add( $$self{_WINDOWCLUSTER}{btnOK} );
	
	return 1;
}

sub _setupCallbacks
{
	my $self = shift;
	
	###############################
	# CLUSTERS RELATED CALLBACKS
	###############################

	$$self{_WINDOWCLUSTER}{treeClustered} -> drag_dest_set( 'GTK_DEST_DEFAULT_ALL', [ 'copy', 'move' ], { target => 'PAC Connect', flags => [] } );
	$$self{_WINDOWCLUSTER}{treeClustered} -> signal_connect( 'drag_motion' => sub { $_[0] -> get_parent_window -> raise; return 1; } );
	$$self{_WINDOWCLUSTER}{treeClustered} -> signal_connect( 'drag_drop' => sub
	{
		my ( $me, $context, $x, $y, $data, $info, $time ) = @_;
		
		my $cluster = $$self{_WINDOWCLUSTER}{comboClusters} -> get_active_text;
		if ( ! $cluster )
		{
			_wMessage( $$self{_WINDOWCLUSTER}{main}, "Before Adding a Terminal to a Cluster, you MUST either:\n - Select an existing CLUSTER\n...or...\n - Create a NEW Cluster" );
			return 0;
		}
		
		my @idx;
		my %tmp;
		foreach my $uuid ( @{ $PACMain::FUNCS{_MAIN}{'DND'}{'selection'} } )
		{
			if ( ( $PACMain::FUNCS{_MAIN}{_CFG}{'environments'}{$uuid}{'_is_group'} ) || ( $uuid eq '__PAC__ROOT__' ) )
			{
				my @children = $PACMain::FUNCS{_MAIN}{_GUI}{treeConnections} -> _getChildren( $uuid, 0, 1 );
				foreach my $child ( @children ) { $tmp{$child} = 1; }
			}
			else
			{
				$tmp{$uuid} = 1;
			}
		}
		foreach my $uuid ( keys %tmp ) { push( @idx, [ $uuid, undef, $cluster ] ); }
		$PACMain::FUNCS{_MAIN} -> _launchTerminals( \@idx );
		
		delete $$self{'DND'}{'selection'};
		
		return 1;
	} );
	
	# Capture 'add cluster' button clicked
	$$self{_WINDOWCLUSTER}{buttonPCC} -> signal_connect( 'clicked' => sub
	{
		$$self{_WINDOWCLUSTER}{main} -> hide;
		$PACMain::FUNCS{_PCC} -> show;
	} );
	
	# Capture 'comboClusters' change
	$$self{_WINDOWCLUSTER}{comboClusters} -> signal_connect( 'changed' => sub { $self -> _comboClustersChanged; } );
	
	# Capture 'add cluster' button clicked
	$$self{_WINDOWCLUSTER}{addCluster} -> signal_connect( 'clicked' => sub
	{
		my $new_cluster = _wEnterValue( $self, 'Enter a name for the <b>New Cluster</b>' );
		
		if ( ( ! defined $new_cluster ) || ( $new_cluster =~ /^\s*$/go ) )
		{
			return 1;
		}
		elsif ( defined $$self{_CLUSTERS}{$new_cluster} )
		{
			_wMessage( $$self{_WINDOWCLUSTER}{main}, "Environment '$new_cluster' already exists!!" );
		}
		
		# Empty the environments combobox
		foreach my $cluster ( keys %{ $$self{_CLUSTERS} } ) { $$self{_WINDOWCLUSTER}{comboClusters} -> remove_text( 0 ); }
		
		$$self{_CLUSTERS}{$new_cluster}{1} = undef;
		
		# Re-populate the clusters combobox
		my $i = 0;
		my $j = 0;
		foreach my $cluster ( sort { uc($a) cmp uc($b) } keys %{ $$self{_CLUSTERS} } )
		{
			$j = $i;
			$$self{_WINDOWCLUSTER}{comboClusters} -> append_text( $cluster );
			$cluster eq $new_cluster and $$self{_WINDOWCLUSTER}{comboClusters} -> set_active( $j );
			++$i;
		}
		
		$$self{_WINDOWCLUSTER}{delCluster}	-> set_sensitive( 1 );
		
		return 1;
	} );
	
	# Capture 'delete cluster' button clicked
	$$self{_WINDOWCLUSTER}{delCluster} -> signal_connect( 'clicked' => sub
	{
		# Get the string of the active cluster
		my $cluster = $$self{_WINDOWCLUSTER}{comboClusters} -> get_active_text();
		
		_wConfirm( $$self{_WINDOWCLUSTER}{main}, "Delete cluster <b>'$cluster'</b>?" ) or return 1;
		
		$$self{_WINDOWCLUSTER}{treeClustered} -> select( 0..1000 );
		$$self{_WINDOWCLUSTER}{btndel} -> clicked;
		
		# Empty the clusters combobox
		foreach my $del_cluster ( keys %{ $$self{_CLUSTERS} } ) { $$self{_WINDOWCLUSTER}{comboClusters} -> remove_text( 0 ); }
		
		# Delete selected cluster
		delete $$self{_CLUSTERS}{$cluster};
		
		# Re-populate the clusters combobox
		foreach my $new_cluster ( sort { uc($a) cmp uc($b) } keys %{ $$self{_CLUSTERS} } ) { $$self{_WINDOWCLUSTER}{comboClusters} -> append_text( $new_cluster ); }
		
		$$self{_WINDOWCLUSTER}{comboClusters} -> set_active( 0 );
		
		return 1;
	} );
	
	$$self{_WINDOWCLUSTER}{treeClustered} -> signal_connect( 'cursor_changed' => sub
	{
		$$self{_WINDOWCLUSTER}{btndel} -> set_sensitive( scalar( @{ $$self{_WINDOWCLUSTER}{treeClustered} -> {data} } ) );
	} );
	
	# Capture 'treeTerminals' row activated
	$$self{_WINDOWCLUSTER}{treeClustered} -> signal_connect( 'row_activated' => sub
	{
		my ( $index ) = $$self{_WINDOWCLUSTER}{treeClustered} -> get_selected_indices;
		return unless defined $index;
		
		$$self{_WINDOWCLUSTER}{btndel} -> clicked;
		return 1;
	} );
	
	# Add terminal to selected cluster
	$$self{_WINDOWCLUSTER}{btnadd}	-> signal_connect( 'clicked' => sub
	{
		my $cluster	= $$self{_WINDOWCLUSTER}{comboClusters}	-> get_active_text();
		my $total	= $$self{_WINDOWCLUSTER}{treeTerminals}	-> get_selected_indices;
		my @select	= $$self{_WINDOWCLUSTER}{treeTerminals}	-> get_selected_indices;
		if ( ! ( $total && ( defined $cluster ) && ( $cluster ne '' ) ) )
		{
			_wMessage( $$self{_WINDOWCLUSTER}{main}, "Before Adding a Terminal to a Cluster, you MUST either:\n - Select an existing CLUSTER\n...or...\n - Create a NEW Cluster" );
			return 1;
		}
		
		foreach my $sel ( sort { $a < $b } @select )
		{
			my $uuid = $$self{_WINDOWCLUSTER}{treeTerminals} -> {data}[$sel][1];
			$self -> addToCluster( $uuid, $cluster );
		}
		
		return 1;
	} );
	
	# Remove selected terminal from current cluster
	$$self{_WINDOWCLUSTER}{btndel}	-> signal_connect( 'clicked' => sub
	{
		my $cluster	= $$self{_WINDOWCLUSTER}{comboClusters}	-> get_active_text();
		my $total	= $$self{_WINDOWCLUSTER}{treeClustered}	-> get_selected_indices;
		my @select	= $$self{_WINDOWCLUSTER}{treeClustered}	-> get_selected_indices;
		return 1 unless ( $total && ( defined $cluster ) && ( $cluster ne '' ) );
		
		foreach my $sel ( sort { $a < $b } @select )
		{
			my $uuid = $$self{_WINDOWCLUSTER}{treeClustered} -> {data}[$sel][1];
			
			$self -> delFromCluster( $uuid, $cluster );
		}
		
		$$self{_WINDOWCLUSTER}{btndel} -> set_sensitive( scalar( @{ $$self{_WINDOWCLUSTER}{treeClustered} -> {data} } ) );
		
		return 1;
	} );
	
	#######################################
	# CONNECTED TERMINALS RELATED CALLBACKS
	#######################################
	
	# Capture 'treeTerminals' row activated
	$$self{_WINDOWCLUSTER}{treeTerminals} -> signal_connect( 'row_activated' => sub
	{
		my ( $index ) = $$self{_WINDOWCLUSTER}{treeTerminals} -> get_selected_indices;
		return unless defined $index;
		
		$$self{_WINDOWCLUSTER}{btnadd} -> clicked;
		return 1;
	} );
	
	$$self{_WINDOWCLUSTER}{treeTerminals} -> signal_connect( 'cursor_changed' => sub
	{
		$$self{_WINDOWCLUSTER}{btnadd} -> set_sensitive( scalar( @{ $$self{_WINDOWCLUSTER}{treeTerminals} -> {data} } ) );
	} );
	
	###############################
	# OTHER CALLBACKS
	###############################
	
	# Capture 'Close' button clicked
	$$self{_WINDOWCLUSTER}{btnOK} -> signal_connect( 'clicked' => sub { $$self{_WINDOWCLUSTER}{main} -> hide; } );
	
	# Capture window closing
	$$self{_WINDOWCLUSTER}{main} -> signal_connect( 'delete_event' => sub
	{
		$$self{_WINDOWCLUSTER}{main} -> hide();
		return 1;
	} );

	$$self{_WINDOWCLUSTER}{main} -> signal_connect( 'key_press_event' => sub
	{
		my ( $widget, $event ) = @_; 
		# Capture 'Esc' keypress to close window
		$event -> keyval == 65307 and $$self{_WINDOWCLUSTER}{main} -> hide;
		return 0;
	} );
	return 1;	
}

sub addToCluster
{
	my $self	= shift;
	my $uuid	= shift;
	my $cluster	= shift;
	
	$$self{_RUNNING}{$uuid}{'terminal'}{_CLUSTER} = $cluster;
	$$self{_RUNNING}{$uuid}{'terminal'}{_GUI}{statusCluster} -> set_from_stock( 'pac-cluster-manager', 'button' ) if defined $$self{_RUNNING}{$uuid}{'terminal'}{_GUI}{statusCluster};
	$$self{_RUNNING}{$uuid}{'terminal'}{_GUI}{statusCluster} -> set_tooltip_text( "In CLUSTER: $cluster" ) if defined $$self{_RUNNING}{$uuid}{'terminal'}{_GUI}{statusCluster};
	$$self{_RUNNING}{$uuid}{'terminal'} -> _updateStatus;
	
	$self -> _updateGUI;
	
	return 1;
}

sub delFromCluster
{
	my $self	= shift;
	my $uuid	= shift;
	my $cluster	= shift;
	
	$$self{_RUNNING}{$uuid}{'terminal'}{_CLUSTER} = '';
	$$self{_RUNNING}{$uuid}{'terminal'}{_GUI}{statusCluster} -> set_from_stock( 'pac-cluster-manager-off', 'button' ) if defined $$self{_RUNNING}{$uuid}{'terminal'}{_GUI}{statusCluster};
	$$self{_RUNNING}{$uuid}{'terminal'}{_GUI}{statusCluster} -> set_tooltip_text( "Unclustered" ) if defined $$self{_RUNNING}{$uuid}{'terminal'}{_GUI}{statusCluster};
	$$self{_RUNNING}{$uuid}{'terminal'} -> _updateStatus;
	
	$self -> _updateGUI;
	
	return 1;
}

sub _updateGUI
{
	my $self = shift;
	
	$$self{_WINDOWCLUSTER}{delCluster}	-> set_sensitive( 0 );
	$$self{_WINDOWCLUSTER}{btnadd}		-> set_sensitive( 0 );
	$$self{_WINDOWCLUSTER}{btndel}		-> set_sensitive( 0 );
	
	# Empty the clusters combobox
	foreach my $cluster ( keys %{ $$self{_CLUSTERS} } ) { $$self{_WINDOWCLUSTER}{comboClusters} -> remove_text( 0 ); }
	# Empty the terminals tree
	@{ $$self{_WINDOWCLUSTER}{treeTerminals} -> {data} } = ();
	# Empty the clustered tree
	@{ $$self{_WINDOWCLUSTER}{treeClustered} -> {data} } = ();
	
	$$self{_CLUSTERS} = undef;
	
	# Look into every startes terminal, and add it to the 'clusteres' or 'unclustered' tree...
	foreach my $uuid ( keys %{ $$self{_RUNNING} } )
	{
		my $name	= $$self{_RUNNING}{$uuid}{'terminal'}{'_NAME'};
		my $icon	= $$self{_RUNNING}{$uuid}{'terminal'}{CONNECTED} ? $ICON_ON : $ICON_OFF;
		
		next unless defined $name && defined $icon;
		
		if ( my $cluster = $$self{_RUNNING}{$uuid}{'terminal'}{_CLUSTER} )
		{
			# Populate the CLUSTER variable
			$$self{_CLUSTERS}{ $cluster }{$uuid} = 1;
			
			# Populate the clustered terminals tree
			push( @{ $$self{_WINDOWCLUSTER}{treeClustered} -> {data} }, [ $name, $uuid, $icon ] );
		}
		else
		{
			# Populate the terminals tree
			push( @{ $$self{_WINDOWCLUSTER}{treeTerminals} -> {data} }, [ $name, $uuid, $icon ] );
		}
	}
	
	# Now, populate the cluters combobox with the configured clusters...
	foreach my $cluster ( keys %{ $$self{_CLUSTERS} } )
	{
		$$self{_WINDOWCLUSTER}{comboClusters}	-> append_text( $cluster );
		$$self{_WINDOWCLUSTER}{comboClusters}	-> set_active( 0 );
		$$self{_WINDOWCLUSTER}{delCluster}		-> set_sensitive( 1 );
	}
	
	$$self{_WINDOWCLUSTER}{addCluster}	-> set_sensitive( 1 );
	my $cluster	= $$self{_WINDOWCLUSTER}{comboClusters}	-> get_active_text();
	$$self{_WINDOWCLUSTER}{btnadd}		-> set_sensitive( scalar( @{ $$self{_WINDOWCLUSTER}{treeTerminals} -> {data} } ) && $cluster );
	$$self{_WINDOWCLUSTER}{btndel}		-> set_sensitive( scalar( @{ $$self{_WINDOWCLUSTER}{treeClustered} -> {data} } ) && $cluster );
	
	$PACMain::FUNCS{_PCC} -> _updateGUI;
	
	return 1;
}

sub _comboClustersChanged
{
	my $self = shift;
	
	my $cluster = $$self{_WINDOWCLUSTER}{comboClusters} -> get_active_text;
	
	$$self{_WINDOWCLUSTER}{addCluster}	-> set_sensitive( 1 );
	$$self{_WINDOWCLUSTER}{delCluster}	-> set_sensitive( 0 );
	$$self{_WINDOWCLUSTER}{btnadd}		-> set_sensitive( 0 );
	$$self{_WINDOWCLUSTER}{btndel}		-> set_sensitive( 0 );
	
	return 1 unless $cluster;
	
	$$self{_WINDOWCLUSTER}{delCluster}	-> set_sensitive( 1 );
	$$self{_WINDOWCLUSTER}{btnadd}		-> set_sensitive( scalar( @{ $$self{_WINDOWCLUSTER}{treeTerminals} -> {data} } ) );
	$$self{_WINDOWCLUSTER}{btndel}		-> set_sensitive( scalar( @{ $$self{_WINDOWCLUSTER}{treeClustered} -> {data} } ) );
	
	# Empty the clustered terminals tree...
	@{ $$self{_WINDOWCLUSTER}{treeClustered} -> {data} } = ();
	
	# ... and repopulate it
	foreach my $uuid ( keys %{ $$self{_CLUSTERS}{$cluster} } )
	{
		next if $uuid eq 1;
		my $name	= $$self{_RUNNING}{$uuid}{'terminal'}{'_NAME'};
		my $icon	= $$self{_RUNNING}{$uuid}{'terminal'}{'CONNECTED'} ? $ICON_ON : $ICON_OFF;
		push( @{ $$self{_WINDOWCLUSTER}{treeClustered} -> {data} }, [ $name, $uuid, $icon ] );
	}
	
	return 1;
}

# END: Define PRIVATE CLASS functions
###################################################################

1;
