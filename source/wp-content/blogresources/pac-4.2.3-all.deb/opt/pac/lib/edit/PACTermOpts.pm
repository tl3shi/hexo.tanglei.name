package PACTermOpts;

##################################################################
# This file is part of PAC( Perl Auto Connector)
#
# Copyright (C) 2010  David Torrejon Vaquerizas
# 
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
###################################################################

$|++;

###################################################################
# Import Modules

# Standard
use strict;
use warnings;

use FindBin qw ( $RealBin $Bin $Script );
#use Data::Dumper;

# GTK2
use Gtk2 '-init';

# PAC modules
use PACUtils;

# END: Import Modules
###################################################################

###################################################################
# Define GLOBAL CLASS variables

my %CURSOR_SHAPE = (
	'block'		=> 0,
	'ibeam'		=> 1,
	'underline'	=> 2
);

my %BACKSPACE_BINDING = (
	'auto'				=> 0,
	'ascii-backspace'	=> 1,
	'ascii-delete'		=> 2,
	'delete-sequence'	=> 3,
	'tty'				=> 4
);

# END: Define GLOBAL CLASS variables
###################################################################

###################################################################
# START: Public class methods

sub new
{
	my $class	= shift;
	my $self	= {};
	
	$self -> {cfg}			= shift;
	$self -> {variables}	= shift;
	
	$self -> {container}	= undef;
	$self -> {gui}			= undef;
	
	_buildTermOptsGUI( $self );
	defined $$self{cfg} and PACTermOpts::update( $$self{cfg} );
	
	bless( $self, $class );
	return $self;
}

sub update
{
	my $self	= shift;
	my $cfg		= shift;
	
	defined $cfg and $$self{cfg} = $cfg;
	
	$$self{gui}{cbCTRLDisable}				-> set_active( $$cfg{'disable CTRL key bindings'} // 0 );
	$$self{gui}{cbALTDisable}				-> set_active( $$cfg{'disable ALT key bindings'} // 0 );
	$$self{gui}{cbSHIFTDisable}				-> set_active( $$cfg{'disable SHIFT key bindings'} // 0 );
	
	$$self{gui}{cbUsePersonal}				-> set_active( 1 ); # Just to force 'toggled' signal to trigger that callback and update GUI
	$$self{gui}{cbUsePersonal}				-> set_active( $$cfg{'use personal settings'} // 0 );
	
	$$self{gui}{entryCfgPrompt}				-> set_text( $$cfg{'command prompt'} // '[#%\$>]|\:\/\s*$' );
	$$self{gui}{entryCfgUserPrompt}			-> set_text( $$cfg{'username prompt'} // '([l|L]ogin|[u|u]suario|[u|U]ser-?[n|N]ame|[u|U]ser):\s*$' );
	$$self{gui}{entryCfgPasswordPrompt}		-> set_text( $$cfg{'password prompt'} // '([p|P]ass|[p|P]ass[w|W]or[d|t]|ontrase.a|Enter passphrase for key \'.+\'):\s*$' );
	
	$$self{gui}{cbTabBackColor}				-> set_active( $$cfg{'use tab back color'} // 0 );
	$$self{gui}{colorTabBack}				-> set_color( $$self{gui}{colorTabBack} -> get_color -> parse( $$cfg{'tab back color'} // '#000000000000' ) );
	$$self{gui}{colorTabBack}				-> set_sensitive( $$self{gui}{cbTabBackColor} -> get_active );
	$$self{gui}{colorText}					-> set_color( $$self{gui}{colorText} -> get_color -> parse( $$cfg{'text color'} // '#cc62cc62cc62' ) );
	$$self{gui}{colorBack}					-> set_color( $$self{gui}{colorBack} -> get_color -> parse( $$cfg{'back color'} // '#000000000000' ) );
	$$self{gui}{colorBold}					-> set_color( $$self{gui}{colorBold} -> get_color -> parse( $$cfg{'bold color'} // $$cfg{'text color'} // '#cc62cc62cc62' ) );
	$$self{gui}{cbBoldAsText}				-> set_active( $$cfg{'bold color like text'} // 1 );
	$$self{gui}{colorBold}					-> set_sensitive( ! $$self{gui}{cbBoldAsText} -> get_active );
	$$self{gui}{fontTerminal}				-> set_font_name( $$cfg{'terminal font'} // 'Monospace 9' );
	$$self{gui}{comboCursorShape}			-> set_active( $CURSOR_SHAPE{ $$cfg{'cursor shape'} // 'block' } );
	$$self{gui}{spCfgTerminalScrollback}	-> set_value( $$cfg{'terminal scrollback lines'} // 5000 );
	$$self{gui}{spCfgTerminalTransparency}	-> set_value( $$cfg{'terminal transparency'} // 0 );
	
	$$self{gui}{spCfgTmoutConnect}			-> set_value( $$cfg{'timeout connect'} // 40 );
	$$self{gui}{spCfgTmoutCommand}			-> set_value( $$cfg{'timeout command'} // 40 );
	
	$$self{gui}{cbCfgNewInTab}				-> set_active( $$cfg{'open in tab'} // 1 );
	$$self{gui}{cbCfgNewInWindow}			-> set_active( ! ( $$cfg{'open in tab'} // 1 ) );
	$$self{gui}{spCfgNewWindowWidth}		-> set_value( $$cfg{'terminal window hsize'} // 800 );
	$$self{gui}{spCfgNewWindowHeight}		-> set_value( $$cfg{'terminal window vsize'} // 600 );
	
	$$self{gui}{entryTermEmulation}			-> set_text( $$cfg{'terminal emulation'} // 'xterm' );
	
	$$self{gui}{comboBackspace}				-> set_active( $BACKSPACE_BINDING{ $$cfg{'terminal backspace'} // 'auto' } // '0' );
	
	$$self{gui}{comboEncoding}				-> set_active( $PACMain::FUNCS{_CONFIG}{_ENCODINGS_MAP}{ $$cfg{'terminal character encoding'} // 'UTF-8' } );
	$$self{gui}{lblEncoding}				-> set_text( $PACMain::FUNCS{_CONFIG}{_ENCODINGS_HASH}{ $$cfg{'terminal character encoding'} // 'RFC 3629' } );
	
	return 1;
}

sub get_cfg
{
	my $self = shift;
	
	my %options;
	
	$options{'disable CTRL key bindings'}	= $$self{gui}{cbCTRLDisable}				-> get_active;
	$options{'disable ALT key bindings'}	= $$self{gui}{cbALTDisable}					-> get_active;
	$options{'disable SHIFT key bindings'}	= $$self{gui}{cbSHIFTDisable}				-> get_active;
	
	$options{'use personal settings'}		= $$self{gui}{cbUsePersonal}				-> get_active // 0;
	
	$options{'command prompt'}				= $$self{gui}{entryCfgPrompt}				-> get_chars( 0, -1 );
	$options{'username prompt'}				= $$self{gui}{entryCfgUserPrompt}			-> get_chars( 0, -1 );
	$options{'password prompt'}				= $$self{gui}{entryCfgPasswordPrompt}		-> get_chars( 0, -1 );
	
	$options{'use tab back color'}			= $$self{gui}{cbTabBackColor}				-> get_active;
	$options{'tab back color'}				= $$self{gui}{colorTabBack}					-> get_color -> to_string;
	$options{'text color'}					= $$self{gui}{colorText}					-> get_color -> to_string;
	$options{'back color'}					= $$self{gui}{colorBack}					-> get_color -> to_string;
	$options{'bold color'}					= $$self{gui}{colorBold}					-> get_color -> to_string;
	$options{'bold color like text'}		= $$self{gui}{cbBoldAsText}					-> get_active;
	$options{'terminal font'}				= $$self{gui}{fontTerminal}					-> get_font_name();
	$options{'cursor shape'}				= $$self{gui}{comboCursorShape}				-> get_active_text;
	$options{'terminal scrollback lines'}	= $$self{gui}{spCfgTerminalScrollback}		-> get_chars( 0, -1 );
	$options{'terminal transparency'}		= $$self{gui}{spCfgTerminalTransparency}	-> get_value;
	
	$options{'timeout connect'}				= $$self{gui}{spCfgTmoutConnect}			-> get_value();
	$options{'timeout command'}				= $$self{gui}{spCfgTmoutCommand}			-> get_value();
	
	$options{'open in tab'}					= $$self{gui}{cbCfgNewInTab}				-> get_active();
	$options{'terminal window hsize'}		= $$self{gui}{spCfgNewWindowWidth}			-> get_value();
	$options{'terminal window vsize'}		= $$self{gui}{spCfgNewWindowHeight}			-> get_value();
	$options{'terminal character encoding'}	= $$self{gui}{comboEncoding}				-> get_active_text;
	$options{'terminal backspace'}			= $$self{gui}{comboBackspace}				-> get_active_text;
	$options{'terminal emulation'}			= $$self{gui}{entryTermEmulation}			-> get_chars( 0, -1 );
	
	return \%options;
}

# END: Public class methods
###################################################################

###################################################################
# START: Private functions definitions

sub _buildTermOptsGUI
{
	my $self		= shift;
	
	my $container	= $self -> {container};
	my $cfg			= $self -> {cfg};
	
	my %w;
	
	# Build main vbox
	$w{vbox} = Gtk2::VBox -> new( 0, 0 );
		
		$w{frameBindings} = Gtk2::Frame -> new( " Disable next key bindings for this connection: " );
		$w{vbox} -> pack_start( $w{frameBindings}, 0, 1, 0 );
			$w{frameBindings} -> set_tooltip_text( "Here you can select which key bindings will not be available in this connection. ");
			
			$w{hboxKBD} = Gtk2::HBox -> new( 0, 0 );
			$w{frameBindings} -> add( $w{hboxKBD} );
			$w{hboxKBD} -> set_border_width( 5 );
				
				$w{cbCTRLDisable} = Gtk2::CheckButton -> new_with_label( 'CTRL' );
				$w{hboxKBD} -> pack_start( $w{cbCTRLDisable}, 0, 1, 0 );
				
				$w{cbALTDisable} = Gtk2::CheckButton -> new_with_label( 'ALT' );
				$w{hboxKBD} -> pack_start( $w{cbALTDisable}, 0, 1, 0 );
				
				$w{cbSHIFTDisable} = Gtk2::CheckButton -> new_with_label( 'SHIFT' );
				$w{hboxKBD} -> pack_start( $w{cbSHIFTDisable}, 0, 1, 0 );
		
		$w{frameSuper} = Gtk2::Frame -> new;
		$w{vbox} -> pack_start( $w{frameSuper}, 1, 1, 0 );
			
			$w{cbUsePersonal} = Gtk2::CheckButton -> new_with_label( ' Use these personal options: ' );
			$w{frameSuper} -> set_label_widget( $w{cbUsePersonal} );
			
			$w{vbox1} = Gtk2::VBox -> new( 0, 0 );
			$w{frameSuper} -> add( $w{vbox1} );
			$w{vbox1} -> set_border_width( 5 );
				
				my $hbox1 = Gtk2::HBox -> new( 0, 0 );
				$w{vbox1} -> pack_start( $hbox1, 0, 1, 0 );
					
					my $frameCommandPrompt = Gtk2::Frame -> new( ' Prompt RegExp: ' );
					$hbox1 -> pack_start( $frameCommandPrompt, 1, 1, 0 );
						
						$w{entryCfgPrompt} = Gtk2::Entry -> new;
						$w{entryCfgPrompt}	-> set_icon_from_stock( 'primary', 'pac-prompt' );
						$frameCommandPrompt -> add( $w{entryCfgPrompt} );
					
					my $frameUserPrompt = Gtk2::Frame -> new( ' Username RegExp: ' );
					$hbox1 -> pack_start( $frameUserPrompt, 1, 1, 0 );
						
						$w{entryCfgUserPrompt} = Gtk2::Entry -> new;
						$frameUserPrompt -> add( $w{entryCfgUserPrompt} );
					
					my $framePasswordPrompt = Gtk2::Frame -> new( ' Password RegExp: ' );
					$hbox1 -> pack_start( $framePasswordPrompt, 1, 1, 0 );
						
						$w{entryCfgPasswordPrompt} = Gtk2::Entry -> new;
						$framePasswordPrompt -> add( $w{entryCfgPasswordPrompt} );
				
				my $frameTermUI = Gtk2::Frame -> new( ' Terminal UI: ' );
				$w{vbox1} -> pack_start( $frameTermUI, 0, 1, 0 );
					
					my $vboxTermUI = Gtk2::VBox -> new( 0, 0 );
					$frameTermUI -> add ( $vboxTermUI );
						
						my $hboxTermUI1 = Gtk2::HBox -> new( 0, 0 );
						$vboxTermUI -> add ( $hboxTermUI1 );
						$hboxTermUI1 -> set_border_width( 5 );
							
							my $frameTxtFore = Gtk2::Frame -> new( 'Text color:' );
							$hboxTermUI1 -> pack_start( $frameTxtFore, 0, 1, 0 );
							$frameTxtFore -> set_shadow_type( 'none' );
								
								$w{colorText} = Gtk2::ColorButton -> new;
								$frameTxtFore -> add( $w{colorText} );
							
							my $frameTxtBack = Gtk2::Frame -> new( 'Back color:' );
							$hboxTermUI1 -> pack_start( $frameTxtBack, 0, 1, 0 );
							$frameTxtBack -> set_shadow_type( 'none' );
								
								$w{colorBack} = Gtk2::ColorButton -> new;
								$frameTxtBack -> add( $w{colorBack} );
							
							my $frameTxtBold = Gtk2::Frame -> new;
							$hboxTermUI1 -> pack_start( $frameTxtBold, 0, 1, 0 );
							$frameTxtBold -> set_shadow_type( 'none' );
								
								$w{cbBoldAsText} = Gtk2::CheckButton -> new_with_label( ' Bold color like Text color: ' );
								$frameTxtBold -> set_label_widget( $w{cbBoldAsText} );
								
								$w{colorBold} = Gtk2::ColorButton -> new;
								$frameTxtBold -> add( $w{colorBold} );
							
							my $frameFont = Gtk2::Frame -> new( 'Font:' );
							$hboxTermUI1 -> pack_start( $frameFont, 0, 1, 0 );
							$frameFont -> set_shadow_type( 'none' );
								
								$w{fontTerminal} = Gtk2::FontButton -> new;
								$frameFont -> add( $w{fontTerminal} );
							
							my $frameTabBackColor = Gtk2::Frame -> new;
							$hboxTermUI1 -> pack_start( $frameTabBackColor, 0, 1, 0 );
							$frameTabBackColor -> set_shadow_type( 'none' );
								
								$w{cbTabBackColor} = Gtk2::CheckButton -> new_with_label( ' Use this Tab background color: ' );
								$frameTabBackColor -> set_label_widget( $w{cbTabBackColor} );
								
								$w{colorTabBack} = Gtk2::ColorButton -> new;
								$frameTabBackColor -> add( $w{colorTabBack} );
						
						my $hboxTermUI2 = Gtk2::HBox -> new( 0, 0 );
						$vboxTermUI -> add ( $hboxTermUI2 );
						$hboxTermUI2 -> set_border_width( 5 );
							
							my $frameCursor = Gtk2::Frame -> new( 'Cursor Shape:' );
							$hboxTermUI2 -> pack_start( $frameCursor, 0, 1, 0 );
							$frameCursor -> set_shadow_type( 'none' );
								
								$w{comboCursorShape} = Gtk2::ComboBox -> new_text;
								$frameCursor -> add( $w{comboCursorShape} );
								foreach my $cursor ( sort { $a cmp $b } keys %CURSOR_SHAPE ) { $w{comboCursorShape} -> append_text( $cursor ); };
							
							my $frameScroll = Gtk2::Frame -> new( 'Scrollback lines:' );
							$hboxTermUI2 -> pack_start( $frameScroll, 0, 1, 0 );
							$frameScroll -> set_shadow_type( 'none' );
								
								$w{spCfgTerminalScrollback} = Gtk2::SpinButton -> new_with_range( 1, 99999, 100 );
								$frameScroll -> add( $w{spCfgTerminalScrollback} );
							
							my $frameTransparency = Gtk2::Frame -> new( 'Transparency:' );
							$hboxTermUI2 -> pack_start( $frameTransparency, 1, 1, 0 );
							$frameTransparency -> set_shadow_type( 'none' );
								
								$w{spCfgTerminalTransparency} = Gtk2::HScale -> new( Gtk2::Adjustment -> new( 0, 0, 1, 0.1, 0.1, 0.1 ) );
								$frameTransparency -> add( $w{spCfgTerminalTransparency} );
							
							my $frameEmulation = Gtk2::Frame -> new( ' Term Emulation: ' );
							$hboxTermUI2 -> pack_start( $frameEmulation, 0, 1, 0 );
								
								$w{entryTermEmulation} = Gtk2::Entry -> new;
								$frameEmulation -> add( $w{entryTermEmulation} );
				
				$w{hboxTimeSize} = Gtk2::HBox -> new( 0, 0 );
				$w{vbox1} -> pack_start( $w{hboxTimeSize}, 0, 1, 0 );
				
				my $frameTimeOuts = Gtk2::Frame -> new( ' Time outs (seconds): ' );
				$w{hboxTimeSize} -> pack_start( $frameTimeOuts, 0, 1, 0 );
					
					my $hbox2 = Gtk2::HBox -> new( 0, 0 );
					$frameTimeOuts -> add( $hbox2 );
					$hbox2 -> set_border_width( 5 );
						
						my $frameTOConn = Gtk2::Frame -> new( ' Connection ' );
						$hbox2 -> pack_start( $frameTOConn, 0, 1, 0 ),
						$frameTOConn -> set_shadow_type( 'none' );
							
							$w{spCfgTmoutConnect} = Gtk2::SpinButton -> new_with_range( 1, 86400, 1 );
							$frameTOConn -> add( $w{spCfgTmoutConnect} );
						
						my $frameTOCmd = Gtk2::Frame -> new( ' Expect Cmd exec: ' );
						$hbox2 -> pack_start( $frameTOCmd, 0, 1, 0 ),
						$frameTOCmd -> set_shadow_type( 'none' );
							
							$w{spCfgTmoutCommand} = Gtk2::SpinButton -> new_with_range( 1, 86400, 1 );
							$frameTOCmd -> add( $w{spCfgTmoutCommand} );
					
					my $frameWindowSize = Gtk2::Frame -> new( ' Open NEW connection on: ' );
					$w{hboxTimeSize} -> pack_start( $frameWindowSize, 0, 1, 0 );
						
						my $vboxWindowSize = Gtk2::VBox -> new( 0, 0 );
						$frameWindowSize -> add( $vboxWindowSize );
							
							$w{cbCfgNewInTab} = Gtk2::RadioButton -> new_with_label( undef, 'Tab' );
							$vboxWindowSize -> pack_start( $w{cbCfgNewInTab}, 0, 1, 0 );
							
							my $hboxWindowSize = Gtk2::HBox -> new( 0, 0 );
							$vboxWindowSize -> pack_start( $hboxWindowSize, 0, 1, 0 );
								
								$w{cbCfgNewInWindow} = Gtk2::RadioButton -> new_with_label( $w{cbCfgNewInTab}, 'Window' );
								$hboxWindowSize -> pack_start( $w{cbCfgNewInWindow}, 0, 1, 0 );
								
								$w{hboxWidthHeight} = Gtk2::HBox -> new( 0, 0 );
								$hboxWindowSize -> pack_start( $w{hboxWidthHeight}, 0, 1, 0 );
									
									$w{hboxWidthHeight} -> pack_start( Gtk2::Label -> new( ' Width: ' ), 0, 1, 0 );
									$w{spCfgNewWindowWidth} = Gtk2::SpinButton -> new_with_range( 1, 4096, 10 );
									$w{hboxWidthHeight} -> pack_start( $w{spCfgNewWindowWidth}, 0, 1, 0 );
									
									$w{hboxWidthHeight} -> pack_start( Gtk2::Label -> new( ' Height: ' ), 0, 1, 0 );
									$w{spCfgNewWindowHeight} = Gtk2::SpinButton -> new_with_range( 1, 4096, 10 );
									$w{hboxWidthHeight} -> pack_start( $w{spCfgNewWindowHeight}, 0, 1, 0 );
					
					my $frameBackspace = Gtk2::Frame -> new( ' Backspace binding: ' );
					$w{hboxTimeSize} -> pack_start( $frameBackspace, 0, 1, 0 );
						
						$w{comboBackspace} = Gtk2::ComboBox -> new_text;
						$frameBackspace -> add( $w{comboBackspace} );
				
				my $frameEncoding = Gtk2::Frame -> new( ' Character Encoding: ' );
				$w{vbox1} -> pack_start( $frameEncoding, 1, 1, 0 );
					
					my $vboxEnc = Gtk2::VBox -> new( 0, 0 );
					$frameEncoding -> add( $vboxEnc );
						
						$w{comboEncoding} = Gtk2::ComboBox -> new_text;
						$vboxEnc -> pack_start( $w{comboEncoding}, 0, 1, 0 );
						
						$w{lblEncoding} = Gtk2::Label -> new( '' );
						$vboxEnc -> pack_start( $w{lblEncoding}, 1, 1, 0 );
				
				my $sep = Gtk2::HSeparator -> new;
				$w{vbox1} -> pack_start( $sep, 0, 1, 5 );
				
				$w{btnResetDefaults} = Gtk2::Button -> new_with_label( 'Reset to DEFAULT values' );
				$w{vbox1} -> pack_start( $w{btnResetDefaults}, 0, 1, 0 );
				$w{btnResetDefaults} -> set_image( Gtk2::Image -> new_from_stock( 'gtk-undo', 'menu' ) );
	
	$$self{container} = $w{vbox};
	$$self{gui} = \%w;
	
	# Populate the Encodings combobox
	foreach my $enc ( sort { uc( $a ) cmp uc( $b ) } keys %{ $PACMain::FUNCS{_CONFIG}{_ENCODINGS_ARRAY} } )
	{
		$w{comboEncoding} -> append_text( $enc );
	}
	
	# Populate the Backspace binding combobox
	foreach my $key ( 'auto', 'ascii-backspace', 'ascii-delete', 'delete-sequence', 'tty' )
	{
		$w{comboBackspace} -> append_text( $key );
	}
	
	# Setup some callbacks
	
	$w{cbUsePersonal} -> signal_connect( 'toggled' => sub { $w{vbox1} -> set_sensitive( $w{cbUsePersonal} -> get_active ); } );
	
	$w{cbTabBackColor} -> signal_connect( 'toggled' => sub { $w{colorTabBack} -> set_sensitive( $w{cbTabBackColor} -> get_active ); } );
	
	$w{cbBoldAsText} -> signal_connect( 'toggled' => sub { $w{colorBold} -> set_sensitive( ! $w{cbBoldAsText} -> get_active ); } );
	
	$w{comboEncoding} -> signal_connect( 'changed' => sub
	{
		$w{lblEncoding} -> set_text( $PACMain::FUNCS{_CONFIG}{_ENCODINGS_HASH}{ $w{comboEncoding} -> get_active_text } // '' );
	} );
	
	$w{cbCfgNewInWindow} -> signal_connect( 'toggled' => sub
	{
		$w{hboxWidthHeight} -> set_sensitive( $w{cbCfgNewInWindow} -> get_active );
		return 1;
	} );
	
	$w{btnResetDefaults} -> signal_connect( 'clicked' => sub
	{
		my %default_cfg;
		defined $default_cfg{'defaults'}{1} or 1;
		
		PACUtils::_cfgSanityCheck( \%default_cfg );
		$self -> update( \%default_cfg );
	} );
	
	return 1;
}

# END: Private functions definitions
###################################################################

1;
