 #include "NativeHelloWorld.h"
JNIEXPORT void JNICALL Java_NativeHelloWorld_nativeHello
  (JNIEnv * j, jobject x)
{
   printf("helloWorld,I am printing in the C ");	
}
